import os
import logging
from datetime import datetime, timedelta
import uuid
from flask import Flask, render_template, request, redirect, url_for, jsonify, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from sqlalchemy.orm import DeclarativeBase
from model import train_model, predict_price, generate_visualization_data, get_feature_importances

# Configure logging
logging.basicConfig(level=logging.DEBUG)

# Database setup
class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)

# Create the Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key")

# Configure database
database_url = os.environ.get("DATABASE_URL")
if database_url:
    app.config["SQLALCHEMY_DATABASE_URI"] = database_url
    app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
        "pool_recycle": 300,
        "pool_pre_ping": True,
    }
else:
    # Fallback for development
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///realestate.db"
    
db.init_app(app)

# Configure login manager
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message_category = 'info'
login_manager.login_message = 'Please log in to access this page.'

@login_manager.user_loader
def load_user(user_id):
    from models import User
    return User.query.get(int(user_id))

# Global variables for model and data
trained_model = None
feature_importances = None

# Initialize the model at startup
def initialize():
    global trained_model, feature_importances
    # Train the model when the app starts
    trained_model, feature_importances = train_model()
    logging.info("Model trained successfully")
    
    # Create all database tables
    with app.app_context():
        db.create_all()

# Initialize the model
initialize()

@app.route('/')
def landing():
    """Render the landing page for visitors"""
    return render_template('landing.html')

@app.route('/dashboard')
@login_required
def index():
    """Render the dashboard with the property input form"""
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
@login_required
def predict():
    """Process form data and make price prediction"""
    try:
        # Extract form data
        square_feet = float(request.form.get('square_feet', 0))
        bedrooms = int(request.form.get('bedrooms', 0))
        bathrooms = float(request.form.get('bathrooms', 0))
        location = request.form.get('location', '')
        property_age = int(request.form.get('property_age', 0))
        has_garage = request.form.get('has_garage') == 'on'
        has_pool = request.form.get('has_pool') == 'on'
        
        # Extract additional property features
        property_type = request.form.get('property_type', 'Single Family')
        lot_size = float(request.form.get('lot_size', square_feet * 2))
        has_basement = request.form.get('has_basement') == 'on'
        has_fireplace = request.form.get('has_fireplace') == 'on'
        year_renovated = int(request.form.get('year_renovated', 0))
        school_rating = int(request.form.get('school_rating', 7))
        walk_score = int(request.form.get('walk_score', 50))
        
        # Create feature dictionary
        property_features = {
            'square_feet': square_feet,
            'bedrooms': bedrooms,
            'bathrooms': bathrooms,
            'location': location,
            'property_age': property_age,
            'has_garage': has_garage,
            'has_pool': has_pool,
            'property_type': property_type,
            'lot_size': lot_size,
            'has_basement': has_basement,
            'has_fireplace': has_fireplace,
            'year_renovated': year_renovated,
            'school_rating': school_rating,
            'walk_score': walk_score
        }
        
        # Make prediction
        predicted_price, confidence_interval = predict_price(trained_model, property_features)
        
        # Generate visualization data
        (price_by_size_data, price_by_bedrooms_data, price_by_location_data,
         price_by_type_data, price_by_walk_score_data, price_by_school_data) = generate_visualization_data(property_features)
        
        # Pass data to template
        return render_template(
            'prediction.html',
            property=property_features,
            predicted_price=predicted_price,
            confidence_interval=confidence_interval,
            price_by_size_data=price_by_size_data,
            price_by_bedrooms_data=price_by_bedrooms_data,
            price_by_location_data=price_by_location_data,
            price_by_type_data=price_by_type_data,
            price_by_walk_score_data=price_by_walk_score_data,
            price_by_school_data=price_by_school_data,
            feature_importances=feature_importances
        )
    
    except Exception as e:
        logging.error(f"Prediction error: {str(e)}")
        flash(f"Error making prediction: {str(e)}", "danger")
        return redirect(url_for('index'))

@app.route('/api/predict', methods=['POST'])
def api_predict():
    """API endpoint for price prediction"""
    try:
        # Get JSON data
        data = request.get_json()
        
        # Make prediction
        predicted_price, confidence_interval = predict_price(trained_model, data)
        
        # Return prediction as JSON
        return jsonify({
            'predicted_price': predicted_price,
            'confidence_interval_low': confidence_interval[0],
            'confidence_interval_high': confidence_interval[1]
        })
    
    except Exception as e:
        logging.error(f"API prediction error: {str(e)}")
        return jsonify({'error': str(e)}), 400

# Authentication routes
@app.route('/login', methods=['GET', 'POST'])
def login():
    """User login route"""
    from models import User
    
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        remember = 'remember' in request.form
        
        # Find user by username
        user = User.query.filter_by(username=username).first()
        
        # Check if user exists and password is correct
        if user and user.check_password(password):
            login_user(user, remember=remember)
            flash('Login successful!', 'success')
            next_page = request.args.get('next')
            return redirect(next_page or url_for('index'))
        else:
            flash('Invalid username or password', 'danger')
    
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    """User registration route"""
    from models import User
    
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        # Check if passwords match
        if password != confirm_password:
            flash('Passwords do not match', 'danger')
            return render_template('signup.html')
        
        # Check if username or email already exists
        if User.query.filter_by(username=username).first():
            flash('Username already taken', 'danger')
            return render_template('signup.html')
        
        if User.query.filter_by(email=email).first():
            flash('Email already registered', 'danger')
            return render_template('signup.html')
        
        # Create new user
        user = User(username=username, email=email)
        user.set_password(password)
        
        # Add user to database
        db.session.add(user)
        db.session.commit()
        
        flash('Account created successfully! You can now log in.', 'success')
        return redirect(url_for('login'))
    
    return render_template('signup.html')

@app.route('/logout')
@login_required
def logout():
    """User logout route"""
    logout_user()
    flash('You have been logged out', 'info')
    return redirect(url_for('landing'))

@app.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    """Forgot password route"""
    from models import User
    
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        email = request.form.get('email')
        
        # Find user by email
        user = User.query.filter_by(email=email).first()
        
        if user:
            # Generate reset token
            token = user.generate_reset_token()
            db.session.commit()
            
            # In a real application, send an email with the reset link
            # Here we'll just display the token in the flash message for demonstration
            reset_url = url_for('reset_password', token=token, _external=True)
            flash(f'Password reset link: {reset_url}', 'info')
            return redirect(url_for('login'))
        else:
            flash('No account found with that email address', 'danger')
    
    return render_template('forgot_password.html')

@app.route('/reset-password/<token>', methods=['GET', 'POST'])
def reset_password(token):
    """Reset password route"""
    from models import User
    
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    # Find user by reset token
    user = User.query.filter_by(reset_token=token).first()
    
    # Check if token is valid and not expired
    if not user or not user.reset_token_expiry or user.reset_token_expiry < datetime.utcnow():
        flash('Invalid or expired reset token', 'danger')
        return redirect(url_for('forgot_password'))
    
    if request.method == 'POST':
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        # Check if passwords match
        if password != confirm_password:
            flash('Passwords do not match', 'danger')
            return render_template('reset_password.html', token=token)
        
        # Update password and clear token
        user.set_password(password)
        user.reset_token = None
        user.reset_token_expiry = None
        db.session.commit()
        
        flash('Password reset successful! You can now log in with your new password.', 'success')
        return redirect(url_for('login'))
    
    return render_template('reset_password.html', token=token)

# Save prediction route (for logged in users)
@app.route('/save-prediction', methods=['POST'])
@login_required
def save_prediction():
    """Save a property prediction to user account"""
    from models import SavedPrediction
    
    try:
        # Get form data
        property_name = request.form.get('property_name')
        square_feet = float(request.form.get('square_feet'))
        bedrooms = int(request.form.get('bedrooms'))
        bathrooms = float(request.form.get('bathrooms'))
        location = request.form.get('location')
        property_age = int(request.form.get('property_age'))
        has_garage = request.form.get('has_garage') == 'on'
        has_pool = request.form.get('has_pool') == 'on'
        property_type = request.form.get('property_type')
        lot_size = float(request.form.get('lot_size'))
        has_basement = request.form.get('has_basement') == 'on'
        has_fireplace = request.form.get('has_fireplace') == 'on'
        year_renovated = int(request.form.get('year_renovated', 0))
        school_rating = int(request.form.get('school_rating'))
        walk_score = int(request.form.get('walk_score'))
        predicted_price = float(request.form.get('predicted_price'))
        
        # Create new saved prediction
        saved_prediction = SavedPrediction(
            user_id=current_user.id,
            property_name=property_name,
            square_feet=square_feet,
            bedrooms=bedrooms,
            bathrooms=bathrooms,
            location=location,
            property_age=property_age,
            has_garage=has_garage,
            has_pool=has_pool,
            property_type=property_type,
            lot_size=lot_size,
            has_basement=has_basement,
            has_fireplace=has_fireplace,
            year_renovated=year_renovated,
            school_rating=school_rating,
            walk_score=walk_score,
            predicted_price=predicted_price
        )
        
        # Add to database
        db.session.add(saved_prediction)
        db.session.commit()
        
        flash('Prediction saved successfully!', 'success')
    except Exception as e:
        logging.error(f"Error saving prediction: {str(e)}")
        flash(f"Error saving prediction: {str(e)}", 'danger')
    
    return redirect(url_for('user_predictions'))

@app.route('/my-predictions')
@login_required
def user_predictions():
    """View saved predictions for the logged in user"""
    from models import SavedPrediction
    
    # Get all predictions for the current user
    predictions = SavedPrediction.query.filter_by(user_id=current_user.id).order_by(SavedPrediction.created_at.desc()).all()
    
    return render_template('my_predictions.html', predictions=predictions)

@app.route('/delete-prediction/<int:prediction_id>', methods=['POST'])
@login_required
def delete_prediction(prediction_id):
    """Delete a saved prediction"""
    from models import SavedPrediction
    
    # Find prediction by ID
    prediction = SavedPrediction.query.get_or_404(prediction_id)
    
    # Check if prediction belongs to current user
    if prediction.user_id != current_user.id:
        flash('You do not have permission to delete this prediction', 'danger')
        return redirect(url_for('user_predictions'))
    
    # Delete prediction
    db.session.delete(prediction)
    db.session.commit()
    
    flash('Prediction deleted successfully', 'success')
    return redirect(url_for('user_predictions'))

@app.route('/mortgage-calculator', methods=['GET'])
def mortgage_calculator():
    """Render the mortgage calculator page"""
    # Get property price from query string (if coming from prediction page)
    property_price = request.args.get('price')
    
    if property_price:
        try:
            property_price = float(property_price)
        except ValueError:
            property_price = None
            
    return render_template('mortgage_calculator.html', property_price=property_price)

@app.route('/profile')
@login_required
def profile():
    """User profile page"""
    from models import SavedPrediction
    
    # Get user's saved predictions
    predictions = SavedPrediction.query.filter_by(user_id=current_user.id).order_by(SavedPrediction.created_at.desc()).all()
    
    return render_template('profile.html', predictions=predictions)

@app.route('/change-password', methods=['POST'])
@login_required
def change_password():
    """Change user password"""
    # Get form data
    current_password = request.form.get('current_password')
    new_password = request.form.get('new_password')
    confirm_password = request.form.get('confirm_password')
    
    # Validate passwords
    if not current_user.check_password(current_password):
        flash('Current password is incorrect', 'danger')
        return redirect(url_for('profile'))
    
    if new_password != confirm_password:
        flash('New passwords do not match', 'danger')
        return redirect(url_for('profile'))
    
    # Update password
    current_user.set_password(new_password)
    db.session.commit()
    
    flash('Password updated successfully', 'success')
    return redirect(url_for('profile'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
