import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import logging
from data.housing_data import get_housing_data

def train_model():
    """
    Train a machine learning model for real estate price prediction
    Returns:
        model: Trained machine learning model
        feature_importances: Dictionary of feature importance scores
    """
    try:
        # Get housing data
        housing_data = get_housing_data()
        
        # Split features and target
        X = housing_data.drop('price', axis=1)
        y = housing_data['price']
        
        # Define categorical and numerical features
        categorical_features = ['location', 'property_type']
        numerical_features = [
            'square_feet', 'bedrooms', 'bathrooms', 'property_age', 
            'has_garage', 'has_pool', 'lot_size', 'has_basement', 
            'has_fireplace', 'year_renovated', 'school_rating', 'walk_score'
        ]
        
        # Create preprocessor
        preprocessor = ColumnTransformer(
            transformers=[
                ('num', StandardScaler(), numerical_features),
                ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_features)
            ]
        )
        
        # Create pipeline with Random Forest Regressor
        model = Pipeline(steps=[
            ('preprocessor', preprocessor),
            ('regressor', RandomForestRegressor(n_estimators=100, random_state=42))
        ])
        
        # Split data into training and testing sets
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        
        # Train the model
        model.fit(X_train, y_train)
        
        # Evaluate the model
        y_pred = model.predict(X_test)
        mae = mean_absolute_error(y_test, y_pred)
        mse = mean_squared_error(y_test, y_pred)
        rmse = np.sqrt(mse)
        r2 = r2_score(y_test, y_pred)
        
        logging.info(f"Model evaluation metrics:")
        logging.info(f"MAE: ${mae:.2f}")
        logging.info(f"RMSE: ${rmse:.2f}")
        logging.info(f"R²: {r2:.4f}")
        
        # Get feature importances from the regressor
        feature_importances = model.named_steps['regressor'].feature_importances_
        
        # Get all transformed feature names
        feature_names = []
        for name, trans, cols in model.named_steps['preprocessor'].transformers_:
            if name == 'num':
                feature_names.extend(cols)
            elif name == 'cat':
                feature_names.extend(trans.get_feature_names_out(cols).tolist())
        
        # Create a dictionary mapping feature names to importance scores
        # Ensure we only use the min of both lengths in case of mismatch
        size = min(len(feature_names), len(feature_importances))
        feature_importance_dict = {feature_names[i]: feature_importances[i] for i in range(size)}
        sorted_importances = dict(sorted(feature_importance_dict.items(), key=lambda x: x[1], reverse=True))
        
        return model, sorted_importances
        
    except Exception as e:
        logging.error(f"Error training model: {str(e)}")
        raise e

def predict_price(model, property_features):
    """
    Make a price prediction for a given property
    
    Args:
        model: Trained machine learning model
        property_features: Dictionary of property features
        
    Returns:
        predicted_price: Predicted price
        confidence_interval: Lower and upper bounds of prediction confidence interval
    """
    try:
        # Convert to DataFrame for prediction
        property_df = pd.DataFrame([property_features])
        
        # Make prediction
        predicted_price = model.predict(property_df)[0]
        
        # Generate confidence interval (simulated for this example)
        # In a real application, this would use a proper confidence interval calculation
        confidence_margin = predicted_price * 0.1  # 10% margin
        confidence_interval = (predicted_price - confidence_margin, predicted_price + confidence_margin)
        
        return predicted_price, confidence_interval
        
    except Exception as e:
        logging.error(f"Error predicting price: {str(e)}")
        raise e

def generate_visualization_data(property_features):
    """
    Generate data for visualizations based on the property features
    
    Args:
        property_features: Dictionary of property features
        
    Returns:
        price_by_size_data: Data for price by size chart
        price_by_bedrooms_data: Data for price by bedrooms chart
        price_by_location_data: Data for price by location chart
    """
    try:
        # Get housing data
        housing_data = get_housing_data()
        
        # Price by size chart data (square feet vs price)
        # Group by 500 sqft ranges
        housing_data['size_range'] = (housing_data['square_feet'] // 500) * 500
        price_by_size = housing_data.groupby('size_range', observed=True)['price'].mean().reset_index()
        price_by_size['size_range'] = price_by_size['size_range'].astype(str) + " sqft"
        price_by_size_data = {
            'labels': price_by_size['size_range'].tolist(),
            'values': price_by_size['price'].tolist()
        }
        
        # Price by bedrooms chart data
        price_by_bedrooms = housing_data.groupby('bedrooms', observed=True)['price'].mean().reset_index()
        price_by_bedrooms_data = {
            'labels': price_by_bedrooms['bedrooms'].tolist(),
            'values': price_by_bedrooms['price'].tolist()
        }
        
        # Price by location chart data
        price_by_location = housing_data.groupby('location', observed=True)['price'].mean().reset_index()
        price_by_location_data = {
            'labels': price_by_location['location'].tolist(),
            'values': price_by_location['price'].tolist()
        }
        
        # Price by property type data
        price_by_type = housing_data.groupby('property_type', observed=True)['price'].mean().reset_index()
        price_by_type_data = {
            'labels': price_by_type['property_type'].tolist(),
            'values': price_by_type['price'].tolist()
        }
        
        # Price by walk score range (binned into categories)
        housing_data['walk_score_range'] = pd.cut(
            housing_data['walk_score'], 
            bins=[0, 25, 50, 75, 100], 
            labels=['Poor (0-25)', 'Fair (26-50)', 'Good (51-75)', 'Excellent (76-100)']
        )
        price_by_walk_score = housing_data.groupby('walk_score_range', observed=True)['price'].mean().reset_index()
        price_by_walk_score_data = {
            'labels': price_by_walk_score['walk_score_range'].tolist(),
            'values': price_by_walk_score['price'].tolist()
        }
        
        # Price by school rating
        price_by_school = housing_data.groupby('school_rating', observed=True)['price'].mean().reset_index()
        price_by_school_data = {
            'labels': price_by_school['school_rating'].astype(str).tolist(),
            'values': price_by_school['price'].tolist()
        }
        
        return (price_by_size_data, price_by_bedrooms_data, price_by_location_data, 
                price_by_type_data, price_by_walk_score_data, price_by_school_data)
        
    except Exception as e:
        logging.error(f"Error generating visualization data: {str(e)}")
        raise e

def get_feature_importances():
    """Get feature importances from the trained model"""
    _, feature_importances = train_model()
    return feature_importances
