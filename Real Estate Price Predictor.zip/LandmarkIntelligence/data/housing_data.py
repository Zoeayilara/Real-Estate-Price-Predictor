import pandas as pd
import numpy as np
from sklearn.datasets import make_regression
import logging

def get_housing_data():
    """
    Generate synthetic housing data for model training and inference
    
    Returns:
        DataFrame: Housing data with features and prices
    """
    try:
        # Generate synthetic data using scikit-learn
        n_samples = 1000
        X, y = make_regression(n_samples=n_samples, n_features=4, noise=25.0, random_state=42)
        
        # Scale the target variable to realistic house prices (in USD)
        y = np.abs(y * 100000 + 300000)
        
        # Create DataFrame with realistic column names
        df = pd.DataFrame(X, columns=['square_feet_raw', 'bedrooms_raw', 'bathrooms_raw', 'property_age_raw'])
        
        # Transform features to more realistic values
        df['square_feet'] = (df['square_feet_raw'] * 500 + 1500).astype(int)  # 1000-2500 sq ft
        df['bedrooms'] = (df['bedrooms_raw'] * 2 + 3).round().astype(int)  # 1-5 bedrooms
        df['bathrooms'] = (df['bathrooms_raw'] * 1.5 + 2).round(1)  # 1-3.5 bathrooms
        df['property_age'] = (df['property_age_raw'] * 20 + 20).round().astype(int)  # 0-40 years old
        
        # Generate categorical and binary features
        locations = ['Urban', 'Suburban', 'Rural', 'Coastal', 'Downtown']
        df['location'] = np.random.choice(locations, size=n_samples)
        df['has_garage'] = np.random.choice([0, 1], size=n_samples, p=[0.3, 0.7])
        df['has_pool'] = np.random.choice([0, 1], size=n_samples, p=[0.8, 0.2])
        
        # Additional property features
        property_types = ['Single Family', 'Townhouse', 'Condo', 'Multi-Family', 'Luxury']
        df['property_type'] = np.random.choice(property_types, size=n_samples)
        
        df['lot_size'] = (df['square_feet'] * np.random.uniform(1.5, 5, size=n_samples)).astype(int)
        df['has_basement'] = np.random.choice([0, 1], size=n_samples, p=[0.5, 0.5])
        df['has_fireplace'] = np.random.choice([0, 1], size=n_samples, p=[0.7, 0.3])
        df['year_renovated'] = np.where(
            np.random.choice([0, 1], size=n_samples, p=[0.6, 0.4]) == 1,
            2023 - (df['property_age'] * np.random.uniform(0.2, 0.8)),
            0
        ).astype(int)
        
        # School ratings (1-10)
        df['school_rating'] = np.random.randint(4, 11, size=n_samples)
        
        # Walk scores (0-100)
        df['walk_score'] = np.random.randint(20, 101, size=n_samples)
        
        # Adjust prices based on these features (introduce some feature importance)
        # Square footage has major impact
        df['price'] = y + (df['square_feet'] - df['square_feet'].mean()) * 200
        
        # Bedrooms and bathrooms have moderate impact
        df['price'] += df['bedrooms'] * 15000
        df['price'] += df['bathrooms'] * 20000
        
        # Location has significant impact
        location_premiums = {
            'Urban': 50000,
            'Suburban': 30000,
            'Rural': -20000,
            'Coastal': 100000,
            'Downtown': 80000
        }
        for loc, premium in location_premiums.items():
            df.loc[df['location'] == loc, 'price'] += premium
        
        # Property age has negative impact (newer is more expensive)
        df['price'] -= df['property_age'] * 2000
        
        # Amenities have positive impact
        df['price'] += df['has_garage'] * 25000
        df['price'] += df['has_pool'] * 40000
        df['price'] += df['has_basement'] * 35000
        df['price'] += df['has_fireplace'] * 15000
        df['price'] += df['school_rating'] * 15000
        df['price'] += df['walk_score'] * 500
        
        # Property type impacts price
        property_type_premiums = {
            'Single Family': 10000,
            'Townhouse': 0,
            'Condo': -15000,
            'Multi-Family': 30000,
            'Luxury': 150000
        }
        for prop_type, premium in property_type_premiums.items():
            df.loc[df['property_type'] == prop_type, 'price'] += premium
            
        # Lot size impacts price
        df['price'] += (df['lot_size'] - df['lot_size'].mean()) * 10
        
        # Year renovated impacts price (if renovation was done)
        df.loc[df['year_renovated'] > 0, 'price'] += 50000
        
        # Ensure no negative prices
        df['price'] = df['price'].clip(lower=100000)
        
        # Round prices to nearest 1000
        df['price'] = (df['price'] / 1000).round() * 1000
        
        # Drop the raw columns
        df = df.drop(['square_feet_raw', 'bedrooms_raw', 'bathrooms_raw', 'property_age_raw'], axis=1)
        
        logging.info(f"Generated housing dataset with {n_samples} samples")
        return df
        
    except Exception as e:
        logging.error(f"Error generating housing data: {str(e)}")
        raise e
