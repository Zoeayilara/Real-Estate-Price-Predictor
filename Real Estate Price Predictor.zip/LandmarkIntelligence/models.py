from flask_login import UserMixin
from datetime import datetime, timedelta
from werkzeug.security import generate_password_hash, check_password_hash
import uuid
from app import db

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    reset_token = db.Column(db.String(100), unique=True, nullable=True)
    reset_token_expiry = db.Column(db.DateTime, nullable=True)
    saved_predictions = db.relationship('SavedPrediction', backref='user', lazy=True)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
        
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def generate_reset_token(self):
        self.reset_token = str(uuid.uuid4())
        self.reset_token_expiry = datetime.utcnow() + timedelta(hours=24)
        return self.reset_token
    
    def __repr__(self):
        return f'<User {self.username}>'

class SavedPrediction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    property_name = db.Column(db.String(100), nullable=False)
    square_feet = db.Column(db.Float, nullable=False)
    bedrooms = db.Column(db.Integer, nullable=False)
    bathrooms = db.Column(db.Float, nullable=False)
    location = db.Column(db.String(100), nullable=False)
    property_age = db.Column(db.Integer, nullable=False)
    has_garage = db.Column(db.Boolean, default=False)
    has_pool = db.Column(db.Boolean, default=False)
    property_type = db.Column(db.String(50), nullable=False)
    lot_size = db.Column(db.Float, nullable=False)
    has_basement = db.Column(db.Boolean, default=False)
    has_fireplace = db.Column(db.Boolean, default=False)
    year_renovated = db.Column(db.Integer, nullable=True)
    school_rating = db.Column(db.Integer, nullable=False)
    walk_score = db.Column(db.Integer, nullable=False)
    predicted_price = db.Column(db.Float, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<SavedPrediction {self.property_name}>'