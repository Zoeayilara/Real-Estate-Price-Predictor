/**
 * Real Estate Price Predictor JavaScript
 * Handles form validation, UI interactions, and chart configurations
 */

document.addEventListener('DOMContentLoaded', function() {
    // Form validation for the prediction form
    const predictionForm = document.getElementById('prediction-form');
    
    if (predictionForm) {
        predictionForm.addEventListener('submit', function(event) {
            // Get form inputs
            const squareFeet = document.getElementById('square_feet').value;
            const bedrooms = document.getElementById('bedrooms').value;
            const bathrooms = document.getElementById('bathrooms').value;
            const location = document.getElementById('location').value;
            const propertyAge = document.getElementById('property_age').value;
            
            // Basic validation
            let isValid = true;
            let errorMessage = '';
            
            // Square feet validation
            if (squareFeet < 500 || squareFeet > 10000) {
                isValid = false;
                errorMessage = 'Square footage must be between 500 and 10,000 square feet.';
            }
            
            // Bedrooms validation
            if (bedrooms < 1 || bedrooms > 10) {
                isValid = false;
                errorMessage = 'Number of bedrooms must be between 1 and 10.';
            }
            
            // Bathrooms validation
            if (bathrooms < 1 || bathrooms > 7) {
                isValid = false;
                errorMessage = 'Number of bathrooms must be between 1 and 7.';
            }
            
            // Location validation
            if (!location) {
                isValid = false;
                errorMessage = 'Please select a location.';
            }
            
            // Property age validation
            if (propertyAge < 0 || propertyAge > 150) {
                isValid = false;
                errorMessage = 'Property age must be between 0 and 150 years.';
            }
            
            // If validation fails, prevent form submission
            if (!isValid) {
                event.preventDefault();
                alert(errorMessage);
            } else {
                // Show loading indicator if form is valid
                const submitButton = predictionForm.querySelector('button[type="submit"]');
                submitButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Processing...';
                submitButton.disabled = true;
            }
        });
    }
    
    // Input value formatters
    const squareFeetInput = document.getElementById('square_feet');
    if (squareFeetInput) {
        // Format square feet input with commas as thousands separators
        squareFeetInput.addEventListener('blur', function() {
            const value = this.value.replace(/,/g, '');
            if (!isNaN(value) && value !== '') {
                this.value = parseInt(value).toLocaleString('en-US', {
                    useGrouping: false,
                    maximumFractionDigits: 0
                });
            }
        });
        
        // Remove formatting when input is focused
        squareFeetInput.addEventListener('focus', function() {
            this.value = this.value.replace(/,/g, '');
        });
    }
    
    // Tooltips initialization (if Bootstrap JS is loaded)
    if (typeof bootstrap !== 'undefined' && bootstrap.Tooltip) {
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function(tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    }
    
    // Make charts responsive to theme changes
    function updateChartsTheme() {
        // Check if Chart.js is loaded and there are charts
        if (typeof Chart !== 'undefined' && Chart.instances) {
            // Get current theme (light or dark)
            const isDarkMode = document.documentElement.getAttribute('data-bs-theme') === 'dark';
            
            // Update chart text color based on theme
            Chart.defaults.color = isDarkMode ? '#f8f9fa' : '#212529';
            
            // Update all charts
            Object.values(Chart.instances).forEach(chart => {
                chart.update();
            });
        }
    }
    
    // Call initially to set correct theme
    updateChartsTheme();
    
    // Enhance form usability with features like autocomplete for locations
    // (Would be expanded with real data in a production application)
    const locationSelect = document.getElementById('location');
    if (locationSelect) {
        // Set default value if there's only one option
        if (locationSelect.options.length === 2) {
            locationSelect.selectedIndex = 1;
        }
    }
});
